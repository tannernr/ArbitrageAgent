import { useState } from 'react';
import Sidebar from './components/layout/Sidebar';
import DashboardView from './views/DashboardView';
import MarketsView from './views/MarketsView';
import TradesView from './views/TradesView';
import PerformanceView from './views/PerformanceView';
import GovernorView from './views/GovernorView';
import ConfigView from './views/ConfigView';
import LogsView from './views/LogsView';
import { useGovernorState } from './hooks/useSupabaseQuery';
import type { ViewName } from './lib/types';

const views: Record<ViewName, React.ComponentType> = {
  dashboard: DashboardView,
  markets: MarketsView,
  trades: TradesView,
  performance: PerformanceView,
  governor: GovernorView,
  config: ConfigView,
  logs: LogsView,
};

function App() {
  const [activeView, setActiveView] = useState<ViewName>('dashboard');
  const { governor } = useGovernorState();

  const ActiveComponent = views[activeView];

  return (
    <div className="min-h-screen bg-gray-950">
      <Sidebar
        activeView={activeView}
        onNavigate={setActiveView}
        governorActive={governor?.is_active ?? true}
      />
      <main className="ml-64 p-8">
        <ActiveComponent />
      </main>
    </div>
  );
}

export default App;
