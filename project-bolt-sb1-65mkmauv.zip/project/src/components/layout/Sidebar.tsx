import {
  LayoutDashboard,
  ScanSearch,
  ArrowLeftRight,
  BarChart3,
  ShieldCheck,
  Settings,
  ScrollText,
  Activity,
} from 'lucide-react';
import type { ViewName } from '../../lib/types';

interface SidebarProps {
  activeView: ViewName;
  onNavigate: (view: ViewName) => void;
  governorActive: boolean;
}

const navItems: Array<{ view: ViewName; label: string; icon: React.ElementType }> = [
  { view: 'dashboard', label: 'Overview', icon: LayoutDashboard },
  { view: 'markets', label: 'Market Scanner', icon: ScanSearch },
  { view: 'trades', label: 'Trade History', icon: ArrowLeftRight },
  { view: 'performance', label: 'Performance', icon: BarChart3 },
  { view: 'governor', label: 'Governor', icon: ShieldCheck },
  { view: 'config', label: 'Configuration', icon: Settings },
  { view: 'logs', label: 'Execution Logs', icon: ScrollText },
];

export default function Sidebar({ activeView, onNavigate, governorActive }: SidebarProps) {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-gray-950 border-r border-gray-800 flex flex-col z-40">
      <div className="p-5 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 flex items-center justify-center">
            <Activity className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-white tracking-tight">Survival Agent</h1>
            <p className="text-xs text-gray-500">Arbitrage Engine</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        {navItems.map(({ view, label, icon: Icon }) => {
          const isActive = activeView === view;
          return (
            <button
              key={view}
              onClick={() => onNavigate(view)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-emerald-500/10 text-emerald-400'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/50'
              }`}
            >
              <Icon className="w-4.5 h-4.5 flex-shrink-0" />
              <span>{label}</span>
              {view === 'governor' && (
                <span
                  className={`ml-auto w-2 h-2 rounded-full ${
                    governorActive ? 'bg-emerald-400' : 'bg-red-400'
                  }`}
                />
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center gap-2 text-xs text-gray-600">
          <div className={`w-1.5 h-1.5 rounded-full ${governorActive ? 'bg-emerald-400' : 'bg-red-400'}`} />
          <span>{governorActive ? 'Agent Active' : 'Agent Halted'}</span>
        </div>
      </div>
    </aside>
  );
}
