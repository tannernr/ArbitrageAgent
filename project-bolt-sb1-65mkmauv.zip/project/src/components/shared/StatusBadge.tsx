interface StatusBadgeProps {
  status: string;
  variant?: 'default' | 'success' | 'danger' | 'warning' | 'info';
}

const variantMap: Record<string, StatusBadgeProps['variant']> = {
  active: 'success',
  executed: 'success',
  settled: 'success',
  detected: 'info',
  pending: 'warning',
  dry_run: 'info',
  paper: 'warning',
  live: 'success',
  halted: 'danger',
  failed: 'danger',
  aborted: 'danger',
  expired: 'default',
  skipped: 'default',
  info: 'info',
  warn: 'warning',
  error: 'danger',
  critical: 'danger',
  halt: 'danger',
  resume: 'success',
  warning: 'warning',
  kill_condition: 'danger',
};

const styles: Record<string, string> = {
  default: 'bg-gray-800 text-gray-400',
  success: 'bg-emerald-500/10 text-emerald-400',
  danger: 'bg-red-500/10 text-red-400',
  warning: 'bg-amber-500/10 text-amber-400',
  info: 'bg-sky-500/10 text-sky-400',
};

export default function StatusBadge({ status, variant }: StatusBadgeProps) {
  const resolvedVariant = variant || variantMap[status] || 'default';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${styles[resolvedVariant]}`}>
      {status.replace(/_/g, ' ')}
    </span>
  );
}
