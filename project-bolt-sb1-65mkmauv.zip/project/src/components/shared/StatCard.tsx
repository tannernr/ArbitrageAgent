import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  trend?: { value: string; positive: boolean } | null;
  variant?: 'default' | 'success' | 'danger' | 'warning';
}

const variantStyles = {
  default: {
    iconBg: 'bg-gray-800',
    iconColor: 'text-gray-400',
  },
  success: {
    iconBg: 'bg-emerald-500/10',
    iconColor: 'text-emerald-400',
  },
  danger: {
    iconBg: 'bg-red-500/10',
    iconColor: 'text-red-400',
  },
  warning: {
    iconBg: 'bg-amber-500/10',
    iconColor: 'text-amber-400',
  },
};

export default function StatCard({ label, value, icon: Icon, trend, variant = 'default' }: StatCardProps) {
  const style = variantStyles[variant];

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-colors">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">{label}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
          {trend && (
            <p className={`text-xs font-medium ${trend.positive ? 'text-emerald-400' : 'text-red-400'}`}>
              {trend.positive ? '+' : ''}{trend.value}
            </p>
          )}
        </div>
        <div className={`p-2.5 rounded-lg ${style.iconBg}`}>
          <Icon className={`w-5 h-5 ${style.iconColor}`} />
        </div>
      </div>
    </div>
  );
}
