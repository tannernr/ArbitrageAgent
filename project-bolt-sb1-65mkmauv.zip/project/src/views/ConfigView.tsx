import { Settings, Info } from 'lucide-react';
import Header from '../components/layout/Header';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { AgentConfig } from '../lib/types';

const configGroups: Record<string, { label: string; keys: string[] }> = {
  capital: {
    label: 'Capital & Sizing',
    keys: ['initial_capital', 'max_trade_size'],
  },
  trading: {
    label: 'Trading Parameters',
    keys: ['safety_margin', 'fee_rate', 'scan_interval_seconds'],
  },
  kill: {
    label: 'Kill Conditions',
    keys: ['kill_max_loss_pct', 'kill_max_drawdown_pct', 'kill_exec_failure_rate', 'kill_no_arb_days'],
  },
  system: {
    label: 'System',
    keys: ['execution_mode', 'market_platforms', 'alert_webhook_url'],
  },
};

function formatValue(value: AgentConfig['value']): string {
  if (Array.isArray(value)) return value.join(', ');
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  return String(value);
}

function formatKey(key: string): string {
  return key
    .replace(/^kill_/, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

export default function ConfigView() {
  const { data: configs, loading, refetch } = useSupabaseQuery<AgentConfig>({
    table: 'agent_config',
    order: { column: 'key', ascending: true },
  });

  const getConfig = (key: string) => configs.find((c) => c.key === key);

  return (
    <div>
      <Header
        title="Configuration"
        subtitle="Agent parameters and thresholds (read-only from dashboard)"
        onRefresh={refetch}
        loading={loading}
      />

      <div className="mb-6 p-4 rounded-xl bg-sky-500/5 border border-sky-500/20 flex items-start gap-3">
        <Info className="w-5 h-5 text-sky-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm text-sky-300">
            Configuration is managed by the Python agent via the database.
          </p>
          <p className="text-xs text-sky-400/60 mt-1">
            To modify values, update them in the agent_config table directly or through the agent's CLI.
          </p>
        </div>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : configs.length === 0 ? (
        <EmptyState
          icon={Settings}
          title="No configuration found"
          description="Configuration will be available once the database migration has been applied."
        />
      ) : (
        <div className="space-y-6">
          {Object.entries(configGroups).map(([groupKey, group]) => (
            <div key={groupKey} className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-gray-800">
                <h3 className="text-sm font-semibold text-white">{group.label}</h3>
              </div>
              <div className="divide-y divide-gray-800">
                {group.keys.map((key) => {
                  const cfg = getConfig(key);
                  if (!cfg) return null;
                  return (
                    <div key={key} className="px-5 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-sm text-white">{formatKey(key)}</p>
                        <p className="text-xs text-gray-600 mt-0.5">{cfg.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-mono text-emerald-400">{formatValue(cfg.value)}</p>
                        <p className="text-xs text-gray-700 mt-0.5">
                          Updated {new Date(cfg.updated_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
