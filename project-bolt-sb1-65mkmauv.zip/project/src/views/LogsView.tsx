import { ScrollText, Filter } from 'lucide-react';
import { useState } from 'react';
import Header from '../components/layout/Header';
import StatusBadge from '../components/shared/StatusBadge';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { ExecutionLog } from '../lib/types';

type LevelFilter = 'all' | ExecutionLog['log_level'];
type ComponentFilter = 'all' | ExecutionLog['component'];

export default function LogsView() {
  const [levelFilter, setLevelFilter] = useState<LevelFilter>('all');
  const [componentFilter, setComponentFilter] = useState<ComponentFilter>('all');

  const filters = [];
  if (levelFilter !== 'all') filters.push({ column: 'log_level', operator: 'eq', value: levelFilter });
  if (componentFilter !== 'all') filters.push({ column: 'component', operator: 'eq', value: componentFilter });

  const { data: logs, loading, refetch } = useSupabaseQuery<ExecutionLog>({
    table: 'execution_logs',
    order: { column: 'created_at', ascending: false },
    filters: filters.length > 0 ? filters : undefined,
    limit: 200,
  });

  const levelColors: Record<string, string> = {
    info: 'text-sky-400',
    warn: 'text-amber-400',
    error: 'text-red-400',
    critical: 'text-red-300 font-bold',
  };

  return (
    <div>
      <Header
        title="Execution Logs"
        subtitle="Structured logs from all agent components"
        onRefresh={refetch}
        loading={loading}
      />

      <div className="flex items-center gap-3 mb-6">
        <Filter className="w-4 h-4 text-gray-500" />
        <select
          value={levelFilter}
          onChange={(e) => setLevelFilter(e.target.value as LevelFilter)}
          className="bg-gray-800 border border-gray-700 text-gray-300 text-sm rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
        >
          <option value="all">All Levels</option>
          <option value="info">Info</option>
          <option value="warn">Warning</option>
          <option value="error">Error</option>
          <option value="critical">Critical</option>
        </select>
        <select
          value={componentFilter}
          onChange={(e) => setComponentFilter(e.target.value as ComponentFilter)}
          className="bg-gray-800 border border-gray-700 text-gray-300 text-sm rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
        >
          <option value="all">All Components</option>
          <option value="collector">Collector</option>
          <option value="detector">Detector</option>
          <option value="executor">Executor</option>
          <option value="auditor">Auditor</option>
          <option value="governor">Governor</option>
        </select>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : logs.length === 0 ? (
        <EmptyState
          icon={ScrollText}
          title="No logs yet"
          description="Execution logs will appear as the agent processes market data and makes decisions."
        />
      ) : (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="divide-y divide-gray-800/50">
            {logs.map((log) => (
              <div
                key={log.id}
                className={`px-5 py-3 hover:bg-gray-800/30 transition-colors ${
                  log.log_level === 'critical' ? 'bg-red-500/5' : ''
                }`}
              >
                <div className="flex items-center gap-3 mb-1">
                  <span className="text-xs text-gray-600 font-mono w-40 flex-shrink-0">
                    {new Date(log.created_at).toLocaleString()}
                  </span>
                  <StatusBadge status={log.log_level} />
                  <span className="text-xs font-medium text-gray-500 bg-gray-800 px-2 py-0.5 rounded">
                    {log.component}
                  </span>
                </div>
                <p className={`text-sm ml-[172px] ${levelColors[log.log_level] || 'text-gray-300'}`}>
                  {log.message}
                </p>
                {log.metadata && (
                  <pre className="text-xs text-gray-600 ml-[172px] mt-1 font-mono overflow-x-auto">
                    {JSON.stringify(log.metadata, null, 2)}
                  </pre>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
