import { ScanSearch, ExternalLink } from 'lucide-react';
import Header from '../components/layout/Header';
import StatusBadge from '../components/shared/StatusBadge';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { Market } from '../lib/types';

export default function MarketsView() {
  const { data: markets, loading, refetch } = useSupabaseQuery<Market>({
    table: 'markets',
    order: { column: 'last_updated', ascending: false },
  });

  const getArbSpread = (m: Market) => {
    if (m.best_ask_yes == null || m.best_ask_no == null) return null;
    return m.best_ask_yes + m.best_ask_no;
  };

  const hasArb = (m: Market) => {
    const spread = getArbSpread(m);
    return spread != null && spread < 1.0;
  };

  const arbMarkets = markets.filter(hasArb);
  const otherMarkets = markets.filter((m) => !hasArb(m));

  return (
    <div>
      <Header
        title="Market Scanner"
        subtitle="Live order book monitoring and arbitrage detection"
        onRefresh={refetch}
        loading={loading}
      />

      {loading ? (
        <LoadingSpinner />
      ) : markets.length === 0 ? (
        <EmptyState
          icon={ScanSearch}
          title="No markets tracked"
          description="The agent hasn't started tracking any markets yet. Markets will appear once the data collector begins scanning."
        />
      ) : (
        <>
          {arbMarkets.length > 0 && (
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <h3 className="text-sm font-semibold text-emerald-400">
                  Active Arbitrage ({arbMarkets.length})
                </h3>
              </div>
              <div className="grid gap-3">
                {arbMarkets.map((market) => (
                  <MarketCard key={market.id} market={market} highlight />
                ))}
              </div>
            </div>
          )}

          <div>
            <h3 className="text-sm font-semibold text-gray-400 mb-4">
              All Markets ({otherMarkets.length})
            </h3>
            <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800">
                      <th className="text-left px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Market
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Ask YES
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Ask NO
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Spread
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Volume
                      </th>
                      <th className="text-center px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {otherMarkets.map((market) => {
                      const spread = getArbSpread(market);
                      return (
                        <tr
                          key={market.id}
                          className="hover:bg-gray-800/50 transition-colors"
                        >
                          <td className="px-5 py-3">
                            <div className="flex items-center gap-2">
                              <p className="text-sm text-white truncate max-w-xs">
                                {market.title}
                              </p>
                              <span className="text-xs text-gray-600">{market.platform}</span>
                            </div>
                          </td>
                          <td className="px-5 py-3 text-right text-sm text-gray-300 font-mono">
                            {market.best_ask_yes?.toFixed(3) ?? '--'}
                          </td>
                          <td className="px-5 py-3 text-right text-sm text-gray-300 font-mono">
                            {market.best_ask_no?.toFixed(3) ?? '--'}
                          </td>
                          <td
                            className={`px-5 py-3 text-right text-sm font-mono font-medium ${
                              spread != null && spread < 1.0
                                ? 'text-emerald-400'
                                : 'text-gray-500'
                            }`}
                          >
                            {spread?.toFixed(4) ?? '--'}
                          </td>
                          <td className="px-5 py-3 text-right text-sm text-gray-500 font-mono">
                            ${market.volume?.toLocaleString() ?? '0'}
                          </td>
                          <td className="px-5 py-3 text-center">
                            <StatusBadge status={market.status} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function MarketCard({ market, highlight }: { market: Market; highlight?: boolean }) {
  const spread = market.best_ask_yes! + market.best_ask_no!;
  const profit = 1.0 - spread;

  return (
    <div
      className={`p-5 rounded-xl border transition-colors ${
        highlight
          ? 'bg-emerald-500/5 border-emerald-500/20 hover:border-emerald-500/40'
          : 'bg-gray-900 border-gray-800 hover:border-gray-700'
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-white truncate">{market.title}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-gray-500">{market.platform}</span>
            <span className="text-xs text-gray-700">|</span>
            <StatusBadge status={market.status} />
          </div>
        </div>
        <ExternalLink className="w-4 h-4 text-gray-600 flex-shrink-0" />
      </div>
      <div className="grid grid-cols-4 gap-4">
        <div>
          <p className="text-xs text-gray-500 mb-1">Ask YES</p>
          <p className="text-sm font-mono font-medium text-white">
            {market.best_ask_yes?.toFixed(3)}
          </p>
        </div>
        <div>
          <p className="text-xs text-gray-500 mb-1">Ask NO</p>
          <p className="text-sm font-mono font-medium text-white">
            {market.best_ask_no?.toFixed(3)}
          </p>
        </div>
        <div>
          <p className="text-xs text-gray-500 mb-1">Total Cost</p>
          <p className="text-sm font-mono font-medium text-white">{spread.toFixed(4)}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500 mb-1">Gross Profit</p>
          <p className="text-sm font-mono font-medium text-emerald-400">
            {(profit * 100).toFixed(2)}%
          </p>
        </div>
      </div>
    </div>
  );
}
