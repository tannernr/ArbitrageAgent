import { ArrowLeftRight, Filter } from 'lucide-react';
import { useState } from 'react';
import Header from '../components/layout/Header';
import StatusBadge from '../components/shared/StatusBadge';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { Trade } from '../lib/types';

type StatusFilter = 'all' | Trade['status'];
type ModeFilter = 'all' | Trade['execution_mode'];

export default function TradesView() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [modeFilter, setModeFilter] = useState<ModeFilter>('all');

  const filters = [];
  if (statusFilter !== 'all') filters.push({ column: 'status', operator: 'eq', value: statusFilter });
  if (modeFilter !== 'all') filters.push({ column: 'execution_mode', operator: 'eq', value: modeFilter });

  const { data: trades, loading, refetch } = useSupabaseQuery<Trade>({
    table: 'trades',
    select: '*, markets(title, platform)',
    order: { column: 'executed_at', ascending: false },
    filters: filters.length > 0 ? filters : undefined,
    limit: 100,
  });

  const formatCurrency = (val: number | null | undefined) =>
    val != null ? `$${val.toFixed(4)}` : '--';

  return (
    <div>
      <Header
        title="Trade History"
        subtitle="All executed and simulated trades"
        onRefresh={refetch}
        loading={loading}
      />

      <div className="flex items-center gap-3 mb-6">
        <Filter className="w-4 h-4 text-gray-500" />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
          className="bg-gray-800 border border-gray-700 text-gray-300 text-sm rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
        >
          <option value="all">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="executed">Executed</option>
          <option value="settled">Settled</option>
          <option value="failed">Failed</option>
          <option value="aborted">Aborted</option>
        </select>
        <select
          value={modeFilter}
          onChange={(e) => setModeFilter(e.target.value as ModeFilter)}
          className="bg-gray-800 border border-gray-700 text-gray-300 text-sm rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
        >
          <option value="all">All Modes</option>
          <option value="dry_run">Dry Run</option>
          <option value="paper">Paper</option>
          <option value="live">Live</option>
        </select>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : trades.length === 0 ? (
        <EmptyState
          icon={ArrowLeftRight}
          title="No trades found"
          description="No trades match the current filters, or the agent hasn't executed any trades yet."
        />
      ) : (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Market
                  </th>
                  <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    YES Price
                  </th>
                  <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    NO Price
                  </th>
                  <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Size
                  </th>
                  <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cost
                  </th>
                  <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Profit
                  </th>
                  <th className="text-center px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Mode
                  </th>
                  <th className="text-center px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {trades.map((trade) => {
                  const profit = trade.actual_profit ?? trade.expected_profit;
                  return (
                    <tr key={trade.id} className="hover:bg-gray-800/50 transition-colors">
                      <td className="px-5 py-3">
                        <p className="text-sm text-white truncate max-w-[200px]">
                          {(trade.markets as unknown as { title: string })?.title || 'Unknown'}
                        </p>
                      </td>
                      <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                        {trade.side_yes_price.toFixed(3)}
                      </td>
                      <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                        {trade.side_no_price.toFixed(3)}
                      </td>
                      <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                        {formatCurrency(trade.size)}
                      </td>
                      <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                        {formatCurrency(trade.total_cost)}
                      </td>
                      <td
                        className={`px-5 py-3 text-right text-sm font-mono font-medium ${
                          profit > 0 ? 'text-emerald-400' : profit < 0 ? 'text-red-400' : 'text-gray-500'
                        }`}
                      >
                        {formatCurrency(profit)}
                      </td>
                      <td className="px-5 py-3 text-center">
                        <StatusBadge status={trade.execution_mode} />
                      </td>
                      <td className="px-5 py-3 text-center">
                        <StatusBadge status={trade.status} />
                      </td>
                      <td className="px-5 py-3 text-right text-xs text-gray-500 whitespace-nowrap">
                        {new Date(trade.executed_at).toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
