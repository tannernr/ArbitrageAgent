import {
  DollarSign,
  TrendingUp,
  ArrowLeftRight,
  ShieldCheck,
  AlertTriangle,
  ScanSearch,
  BarChart3,
  Clock,
} from 'lucide-react';
import Header from '../components/layout/Header';
import StatCard from '../components/shared/StatCard';
import StatusBadge from '../components/shared/StatusBadge';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useGovernorState, useLatestPerformance, useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { Trade, ArbitrageOpportunity } from '../lib/types';

export default function DashboardView() {
  const { governor, loading: govLoading } = useGovernorState();
  const { performance, loading: perfLoading } = useLatestPerformance();
  const { data: recentTrades, loading: tradesLoading } = useSupabaseQuery<Trade>({
    table: 'trades',
    select: '*, markets(title, platform)',
    order: { column: 'executed_at', ascending: false },
    limit: 5,
  });
  const { data: recentOpps, loading: oppsLoading } = useSupabaseQuery<ArbitrageOpportunity>({
    table: 'arbitrage_opportunities',
    select: '*, markets(title, platform)',
    order: { column: 'detected_at', ascending: false },
    limit: 5,
  });

  const loading = govLoading || perfLoading || tradesLoading || oppsLoading;

  const formatCurrency = (val: number | null | undefined) =>
    val != null ? `$${val.toFixed(2)}` : '$0.00';

  const formatPercent = (val: number | null | undefined) =>
    val != null ? `${(val * 100).toFixed(2)}%` : '0.00%';

  return (
    <div>
      <Header title="Dashboard" subtitle="Survival Arbitrage Agent Overview" />

      {governor && (
        <div
          className={`mb-6 p-4 rounded-xl border flex items-center gap-3 ${
            governor.is_active
              ? 'bg-emerald-500/5 border-emerald-500/20'
              : 'bg-red-500/5 border-red-500/20'
          }`}
        >
          <ShieldCheck
            className={`w-5 h-5 ${governor.is_active ? 'text-emerald-400' : 'text-red-400'}`}
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-white">
              Governor: {governor.is_active ? 'Active' : 'Halted'}
            </span>
            {governor.halt_reason && (
              <span className="text-xs text-red-400 ml-3">{governor.halt_reason}</span>
            )}
          </div>
          <StatusBadge status={governor.mode} />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Total Profit"
          value={formatCurrency(performance?.total_profit)}
          icon={DollarSign}
          variant={performance && performance.total_profit > 0 ? 'success' : 'default'}
        />
        <StatCard
          label="ROI"
          value={formatPercent(performance?.roi)}
          icon={TrendingUp}
          variant={performance && performance.roi > 0 ? 'success' : 'default'}
        />
        <StatCard
          label="Total Trades"
          value={String(performance?.total_trades ?? 0)}
          icon={ArrowLeftRight}
        />
        <StatCard
          label="Max Drawdown"
          value={formatPercent(performance?.max_drawdown)}
          icon={AlertTriangle}
          variant={performance && performance.max_drawdown > 0.005 ? 'danger' : 'warning'}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Win Rate"
          value={formatPercent(performance?.win_rate)}
          icon={BarChart3}
          variant="success"
        />
        <StatCard
          label="Failure Rate"
          value={formatPercent(performance?.execution_failure_rate)}
          icon={AlertTriangle}
          variant={
            performance && performance.execution_failure_rate > 0.01 ? 'danger' : 'default'
          }
        />
        <StatCard
          label="Days No Arb"
          value={String(governor?.consecutive_days_no_arb ?? 0)}
          icon={Clock}
          variant={
            governor && governor.consecutive_days_no_arb > 3 ? 'warning' : 'default'
          }
        />
        <StatCard
          label="Current Drawdown"
          value={formatPercent(performance?.current_drawdown)}
          icon={TrendingUp}
          variant={performance && performance.current_drawdown > 0.005 ? 'danger' : 'default'}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-900 border border-gray-800 rounded-xl">
          <div className="px-5 py-4 border-b border-gray-800 flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-gray-500" />
            <h3 className="text-sm font-semibold text-white">Recent Trades</h3>
          </div>
          {loading ? (
            <LoadingSpinner />
          ) : recentTrades.length === 0 ? (
            <EmptyState
              title="No trades yet"
              description="The agent hasn't executed any trades. Trades will appear here once the agent finds arbitrage opportunities."
            />
          ) : (
            <div className="divide-y divide-gray-800">
              {recentTrades.map((trade) => (
                <div key={trade.id} className="px-5 py-3 flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-white truncate">
                      {(trade.markets as unknown as { title: string })?.title || 'Unknown Market'}
                    </p>
                    <p className="text-xs text-gray-600 mt-0.5">
                      {new Date(trade.executed_at).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 ml-4">
                    <span
                      className={`text-sm font-medium ${
                        (trade.actual_profit ?? trade.expected_profit) > 0
                          ? 'text-emerald-400'
                          : 'text-red-400'
                      }`}
                    >
                      {formatCurrency(trade.actual_profit ?? trade.expected_profit)}
                    </span>
                    <StatusBadge status={trade.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-xl">
          <div className="px-5 py-4 border-b border-gray-800 flex items-center gap-2">
            <ScanSearch className="w-4 h-4 text-gray-500" />
            <h3 className="text-sm font-semibold text-white">Recent Opportunities</h3>
          </div>
          {loading ? (
            <LoadingSpinner />
          ) : recentOpps.length === 0 ? (
            <EmptyState
              title="No opportunities detected"
              description="The scanner hasn't found any arbitrage opportunities yet. This is normal — inactivity is not failure."
            />
          ) : (
            <div className="divide-y divide-gray-800">
              {recentOpps.map((opp) => (
                <div key={opp.id} className="px-5 py-3 flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-white truncate">
                      {(opp.markets as unknown as { title: string })?.title || 'Unknown Market'}
                    </p>
                    <p className="text-xs text-gray-600 mt-0.5">
                      Margin: {(opp.profit_margin * 100).toFixed(3)}%
                    </p>
                  </div>
                  <div className="flex items-center gap-3 ml-4">
                    <span className="text-sm font-medium text-emerald-400">
                      {formatCurrency(opp.estimated_profit)}
                    </span>
                    <StatusBadge status={opp.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
