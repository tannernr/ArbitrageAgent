import {
  DollarSign,
  TrendingUp,
  Target,
  AlertTriangle,
  BarChart3,
  XCircle,
  ArrowDownRight,
  Activity,
} from 'lucide-react';
import Header from '../components/layout/Header';
import StatCard from '../components/shared/StatCard';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useLatestPerformance, useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { PerformanceSnapshot } from '../lib/types';

export default function PerformanceView() {
  const { performance, loading: latestLoading, refetch } = useLatestPerformance();
  const { data: history, loading: historyLoading } = useSupabaseQuery<PerformanceSnapshot>({
    table: 'performance_snapshots',
    order: { column: 'snapshot_at', ascending: false },
    limit: 50,
  });

  const loading = latestLoading || historyLoading;

  const fmt = (val: number | null | undefined) =>
    val != null ? `$${val.toFixed(2)}` : '$0.00';
  const pct = (val: number | null | undefined) =>
    val != null ? `${(val * 100).toFixed(2)}%` : '0.00%';

  return (
    <div>
      <Header
        title="Performance Auditor"
        subtitle="Profit, loss, and risk metrics"
        onRefresh={refetch}
        loading={loading}
      />

      {loading ? (
        <LoadingSpinner />
      ) : !performance ? (
        <EmptyState
          icon={BarChart3}
          title="No performance data"
          description="Performance snapshots will be generated as the agent runs and records trades."
        />
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard
              label="Net Profit"
              value={fmt(performance.total_profit)}
              icon={DollarSign}
              variant={performance.total_profit > 0 ? 'success' : performance.total_profit < 0 ? 'danger' : 'default'}
            />
            <StatCard
              label="ROI"
              value={pct(performance.roi)}
              icon={TrendingUp}
              variant={performance.roi > 0 ? 'success' : 'default'}
            />
            <StatCard
              label="Win Rate"
              value={pct(performance.win_rate)}
              icon={Target}
              variant={performance.win_rate > 0.9 ? 'success' : performance.win_rate > 0.5 ? 'warning' : 'danger'}
            />
            <StatCard
              label="Max Drawdown"
              value={pct(performance.max_drawdown)}
              icon={AlertTriangle}
              variant={performance.max_drawdown > 0.01 ? 'danger' : performance.max_drawdown > 0.005 ? 'warning' : 'default'}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard
              label="Total Trades"
              value={String(performance.total_trades)}
              icon={Activity}
            />
            <StatCard
              label="Winning Trades"
              value={String(performance.winning_trades)}
              icon={TrendingUp}
              variant="success"
            />
            <StatCard
              label="Losing Trades"
              value={String(performance.losing_trades)}
              icon={ArrowDownRight}
              variant={performance.losing_trades > 0 ? 'danger' : 'default'}
            />
            <StatCard
              label="Exec Failures"
              value={`${performance.execution_failure_count} (${pct(performance.execution_failure_rate)})`}
              icon={XCircle}
              variant={performance.execution_failure_rate > 0.02 ? 'danger' : 'default'}
            />
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-xl">
            <div className="px-5 py-4 border-b border-gray-800">
              <h3 className="text-sm font-semibold text-white">Snapshot History</h3>
            </div>
            {history.length === 0 ? (
              <div className="p-8 text-center text-sm text-gray-600">No history available</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800">
                      <th className="text-left px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Time
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Trades
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Profit
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ROI
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Win Rate
                      </th>
                      <th className="text-right px-5 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Drawdown
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {history.map((snap) => (
                      <tr key={snap.id} className="hover:bg-gray-800/50 transition-colors">
                        <td className="px-5 py-3 text-sm text-gray-400">
                          {new Date(snap.snapshot_at).toLocaleString()}
                        </td>
                        <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                          {snap.total_trades}
                        </td>
                        <td
                          className={`px-5 py-3 text-right text-sm font-mono font-medium ${
                            snap.total_profit > 0 ? 'text-emerald-400' : snap.total_profit < 0 ? 'text-red-400' : 'text-gray-500'
                          }`}
                        >
                          {fmt(snap.total_profit)}
                        </td>
                        <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                          {pct(snap.roi)}
                        </td>
                        <td className="px-5 py-3 text-right text-sm font-mono text-gray-300">
                          {pct(snap.win_rate)}
                        </td>
                        <td
                          className={`px-5 py-3 text-right text-sm font-mono ${
                            snap.max_drawdown > 0.01 ? 'text-red-400' : 'text-gray-500'
                          }`}
                        >
                          {pct(snap.max_drawdown)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
