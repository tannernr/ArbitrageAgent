import {
  ShieldCheck,
  ShieldOff,
  AlertOctagon,
  Clock,
  Activity,
  Zap,
  XCircle,
  CalendarX,
} from 'lucide-react';
import Header from '../components/layout/Header';
import StatusBadge from '../components/shared/StatusBadge';
import EmptyState from '../components/shared/EmptyState';
import LoadingSpinner from '../components/shared/LoadingSpinner';
import { useGovernorState, useLatestPerformance, useSupabaseQuery } from '../hooks/useSupabaseQuery';
import type { GovernorEvent, AgentConfig } from '../lib/types';

export default function GovernorView() {
  const { governor, loading: govLoading, refetch } = useGovernorState();
  const { performance } = useLatestPerformance();
  const { data: events, loading: eventsLoading } = useSupabaseQuery<GovernorEvent>({
    table: 'governor_events',
    order: { column: 'created_at', ascending: false },
    limit: 50,
  });
  const { data: configs } = useSupabaseQuery<AgentConfig>({
    table: 'agent_config',
    filters: [{ column: 'key', operator: 'like', value: 'kill_%' }],
  });

  const loading = govLoading || eventsLoading;

  const getConfigValue = (key: string): string => {
    const cfg = configs.find((c) => c.key === key);
    return cfg ? String(cfg.value) : '--';
  };

  const killConditions = [
    {
      label: 'Max Realized Loss',
      icon: XCircle,
      threshold: getConfigValue('kill_max_loss_pct'),
      current: performance ? `${(performance.total_profit < 0 ? Math.abs(performance.total_profit / (performance.total_invested || 1)) * 100 : 0).toFixed(3)}%` : '--',
      triggered: performance ? performance.total_profit < 0 && Math.abs(performance.total_profit / (performance.total_invested || 1)) > Number(getConfigValue('kill_max_loss_pct')) : false,
    },
    {
      label: 'Max Drawdown',
      icon: AlertOctagon,
      threshold: getConfigValue('kill_max_drawdown_pct'),
      current: performance ? `${(performance.max_drawdown * 100).toFixed(3)}%` : '--',
      triggered: performance ? performance.max_drawdown > Number(getConfigValue('kill_max_drawdown_pct')) : false,
    },
    {
      label: 'Execution Failure Rate',
      icon: Zap,
      threshold: getConfigValue('kill_exec_failure_rate'),
      current: performance ? `${(performance.execution_failure_rate * 100).toFixed(3)}%` : '--',
      triggered: performance ? performance.execution_failure_rate > Number(getConfigValue('kill_exec_failure_rate')) : false,
    },
    {
      label: 'Consecutive Days No Arb',
      icon: CalendarX,
      threshold: getConfigValue('kill_no_arb_days'),
      current: governor ? String(governor.consecutive_days_no_arb) : '--',
      triggered: governor ? governor.consecutive_days_no_arb > Number(getConfigValue('kill_no_arb_days')) : false,
    },
  ];

  return (
    <div>
      <Header
        title="Survival Governor"
        subtitle="Kill conditions, halt status, and event history"
        onRefresh={refetch}
        loading={loading}
      />

      {loading ? (
        <LoadingSpinner />
      ) : (
        <>
          {governor && (
            <div
              className={`mb-8 p-6 rounded-xl border ${
                governor.is_active
                  ? 'bg-emerald-500/5 border-emerald-500/20'
                  : 'bg-red-500/5 border-red-500/20'
              }`}
            >
              <div className="flex items-center gap-4 mb-4">
                {governor.is_active ? (
                  <ShieldCheck className="w-8 h-8 text-emerald-400" />
                ) : (
                  <ShieldOff className="w-8 h-8 text-red-400" />
                )}
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {governor.is_active ? 'Governor Active' : 'Trading Halted'}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {governor.is_active
                      ? 'All systems nominal. Trading is allowed.'
                      : governor.halt_reason || 'Trading has been stopped.'}
                  </p>
                </div>
                <div className="ml-auto">
                  <StatusBadge status={governor.mode} />
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Mode</p>
                  <p className="text-sm font-medium text-white">{governor.mode.replace(/_/g, ' ')}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Last Trade</p>
                  <p className="text-sm text-gray-300">
                    {governor.last_trade_at
                      ? new Date(governor.last_trade_at).toLocaleString()
                      : 'Never'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Last Opportunity</p>
                  <p className="text-sm text-gray-300">
                    {governor.last_opportunity_at
                      ? new Date(governor.last_opportunity_at).toLocaleString()
                      : 'Never'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Days No Arb</p>
                  <p className="text-sm text-gray-300">{governor.consecutive_days_no_arb}</p>
                </div>
              </div>
            </div>
          )}

          <div className="mb-8">
            <h3 className="text-sm font-semibold text-white mb-4">Kill Conditions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {killConditions.map((condition) => (
                <div
                  key={condition.label}
                  className={`p-4 rounded-xl border ${
                    condition.triggered
                      ? 'bg-red-500/5 border-red-500/20'
                      : 'bg-gray-900 border-gray-800'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <condition.icon
                      className={`w-4.5 h-4.5 ${
                        condition.triggered ? 'text-red-400' : 'text-gray-500'
                      }`}
                    />
                    <span className="text-sm font-medium text-white">{condition.label}</span>
                    {condition.triggered && (
                      <span className="ml-auto text-xs font-medium text-red-400 bg-red-500/10 px-2 py-0.5 rounded-full">
                        TRIGGERED
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-gray-500">Current</p>
                      <p className="text-sm font-mono text-gray-300">{condition.current}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-500">Threshold</p>
                      <p className="text-sm font-mono text-gray-300">{condition.threshold}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-xl">
            <div className="px-5 py-4 border-b border-gray-800 flex items-center gap-2">
              <Activity className="w-4 h-4 text-gray-500" />
              <h3 className="text-sm font-semibold text-white">Governor Events</h3>
            </div>
            {events.length === 0 ? (
              <EmptyState
                icon={Clock}
                title="No events yet"
                description="Governor events will appear as the agent runs and makes decisions."
              />
            ) : (
              <div className="divide-y divide-gray-800">
                {events.map((event) => (
                  <div key={event.id} className="px-5 py-3 flex items-center gap-4">
                    <StatusBadge status={event.event_type} />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-white">{event.message}</p>
                      <p className="text-xs text-gray-600 mt-0.5">
                        {event.trigger_name}
                        {event.trigger_value && ` = ${event.trigger_value}`}
                        {event.threshold_value && ` (threshold: ${event.threshold_value})`}
                      </p>
                    </div>
                    <span className="text-xs text-gray-600 whitespace-nowrap">
                      {new Date(event.created_at).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
