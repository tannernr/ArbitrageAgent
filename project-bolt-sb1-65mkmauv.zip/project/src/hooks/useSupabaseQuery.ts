import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';

interface QueryOptions {
  table: string;
  select?: string;
  order?: { column: string; ascending?: boolean };
  limit?: number;
  filters?: Array<{ column: string; operator: string; value: unknown }>;
  enabled?: boolean;
}

interface QueryResult<T> {
  data: T[];
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useSupabaseQuery<T>(options: QueryOptions): QueryResult<T> {
  const { table, select = '*', order, limit, filters, enabled = true } = options;
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!enabled) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      let query = supabase.from(table).select(select);

      if (filters) {
        for (const f of filters) {
          query = query.filter(f.column, f.operator, f.value);
        }
      }

      if (order) {
        query = query.order(order.column, { ascending: order.ascending ?? false });
      }

      if (limit) {
        query = query.limit(limit);
      }

      const { data: result, error: queryError } = await query;

      if (queryError) {
        setError(queryError.message);
      } else {
        setData((result as T[]) || []);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [table, select, order?.column, order?.ascending, limit, enabled, JSON.stringify(filters)]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
}

export function useGovernorState() {
  const { data, loading, error, refetch } = useSupabaseQuery<import('../lib/types').GovernorState>({
    table: 'governor_state',
    limit: 1,
  });
  return { governor: data[0] || null, loading, error, refetch };
}

export function useLatestPerformance() {
  const { data, loading, error, refetch } = useSupabaseQuery<import('../lib/types').PerformanceSnapshot>({
    table: 'performance_snapshots',
    order: { column: 'snapshot_at', ascending: false },
    limit: 1,
  });
  return { performance: data[0] || null, loading, error, refetch };
}
