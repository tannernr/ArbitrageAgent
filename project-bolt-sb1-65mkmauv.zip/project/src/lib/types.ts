export interface AgentConfig {
  id: string;
  key: string;
  value: string | number | boolean | string[];
  description: string;
  updated_at: string;
}

export interface Market {
  id: string;
  external_id: string;
  platform: 'polymarket' | 'kalshi';
  title: string;
  category: string;
  status: 'active' | 'settled' | 'expired';
  best_ask_yes: number | null;
  best_ask_no: number | null;
  best_bid_yes: number | null;
  best_bid_no: number | null;
  volume: number;
  last_updated: string;
  created_at: string;
}

export interface ArbitrageOpportunity {
  id: string;
  market_id: string;
  best_ask_yes: number;
  best_ask_no: number;
  total_cost: number;
  estimated_profit: number;
  profit_margin: number;
  fees: number;
  safety_margin: number;
  status: 'detected' | 'executed' | 'expired' | 'skipped';
  detected_at: string;
  markets?: Market;
}

export interface Trade {
  id: string;
  opportunity_id: string | null;
  market_id: string;
  side_yes_price: number;
  side_no_price: number;
  size: number;
  total_cost: number;
  expected_profit: number;
  actual_profit: number | null;
  status: 'pending' | 'executed' | 'settled' | 'failed' | 'aborted';
  execution_mode: 'dry_run' | 'paper' | 'live';
  executed_at: string;
  settled_at: string | null;
  markets?: Market;
}

export interface PerformanceSnapshot {
  id: string;
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  total_profit: number;
  total_invested: number;
  roi: number;
  win_rate: number;
  max_drawdown: number;
  current_drawdown: number;
  execution_failure_count: number;
  execution_failure_rate: number;
  snapshot_at: string;
}

export interface GovernorState {
  id: string;
  is_active: boolean;
  mode: 'dry_run' | 'paper' | 'live' | 'halted';
  last_trade_at: string | null;
  last_opportunity_at: string | null;
  consecutive_days_no_arb: number;
  halt_reason: string | null;
  halted_at: string | null;
  updated_at: string;
}

export interface GovernorEvent {
  id: string;
  event_type: 'halt' | 'resume' | 'warning' | 'kill_condition';
  trigger_name: string;
  trigger_value: string | null;
  threshold_value: string | null;
  message: string;
  created_at: string;
}

export interface ExecutionLog {
  id: string;
  trade_id: string | null;
  log_level: 'info' | 'warn' | 'error' | 'critical';
  component: 'collector' | 'detector' | 'executor' | 'auditor' | 'governor';
  message: string;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export type ViewName = 'dashboard' | 'markets' | 'trades' | 'performance' | 'governor' | 'config' | 'logs';
