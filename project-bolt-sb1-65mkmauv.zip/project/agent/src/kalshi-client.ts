import crypto from 'node:crypto';
import { config } from './config.js';

interface KalshiMarket {
  ticker: string;
  event_ticker: string;
  market_type: string;
  yes_sub_title: string;
  no_sub_title: string;
  yes_ask_dollars: string;
  no_ask_dollars: string;
  yes_bid_dollars: string;
  no_bid_dollars: string;
  last_price_dollars: string;
  volume_fp: string;
  volume_24h_fp: string;
  open_interest_fp: string;
  status: string;
  result: string;
  close_time: string;
  created_time: string;
  updated_time: string;
}

interface GetMarketsResponse {
  markets: KalshiMarket[];
  cursor: string;
}

function signRequest(timestamp: string, method: string, path: string): string {
  const message = timestamp + method.toUpperCase() + path;
  const sign = crypto.createSign('RSA-SHA256');
  sign.update(message);
  sign.end();
  return sign.sign(
    {
      key: config.kalshi.privateKeyPem,
      padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
      saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
    },
    'base64'
  );
}

function buildHeaders(method: string, path: string): Record<string, string> {
  const timestamp = Date.now().toString();
  const pathWithoutQuery = path.split('?')[0];
  const signature = signRequest(timestamp, method, pathWithoutQuery);

  return {
    'KALSHI-ACCESS-KEY': config.kalshi.apiKeyId,
    'KALSHI-ACCESS-SIGNATURE': signature,
    'KALSHI-ACCESS-TIMESTAMP': timestamp,
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
}

async function request<T>(method: string, path: string): Promise<T> {
  const url = config.kalshi.baseUrl + path;
  const headers = buildHeaders(method, path);

  const res = await fetch(url, { method, headers });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Kalshi API ${method} ${path} failed (${res.status}): ${body}`);
  }

  return res.json() as Promise<T>;
}

export async function fetchOpenMarkets(limit = 200): Promise<KalshiMarket[]> {
  const allMarkets: KalshiMarket[] = [];
  let cursor = '';

  do {
    const params = new URLSearchParams({ status: 'open', limit: String(limit) });
    if (cursor) params.set('cursor', cursor);

    const path = `/markets?${params.toString()}`;
    const data = await request<GetMarketsResponse>('GET', path);

    allMarkets.push(...data.markets);
    cursor = data.cursor;
  } while (cursor);

  return allMarkets;
}

export type { KalshiMarket };
