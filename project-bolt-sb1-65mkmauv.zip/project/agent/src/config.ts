function required(name: string): string {
  const val = process.env[name];
  if (!val) throw new Error(`Missing required env var: ${name}`);
  return val;
}

export const config = {
  supabase: {
    url: required('SUPABASE_URL'),
    serviceRoleKey: required('SUPABASE_SERVICE_ROLE_KEY'),
  },
  kalshi: {
    apiKeyId: required('KALSHI_API_KEY_ID'),
    privateKeyPem: required('KALSHI_PRIVATE_KEY_PEM').replace(/\\n/g, '\n'),
    baseUrl: process.env.KALSHI_BASE_URL || 'https://api.elections.kalshi.com/trade-api/v2',
  },
} as const;
