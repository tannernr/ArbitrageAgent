import { fetchOpenMarkets, type KalshiMarket } from './kalshi-client.js';
import { supabase } from './supabase.js';
import { log } from './logger.js';

function mapStatus(kalshiStatus: string): 'active' | 'settled' | 'expired' {
  switch (kalshiStatus) {
    case 'active':
    case 'open':
      return 'active';
    case 'closed':
    case 'determined':
    case 'finalized':
    case 'settled':
      return 'settled';
    default:
      return 'expired';
  }
}

function parseDollar(val: string | null | undefined): number | null {
  if (!val) return null;
  const n = parseFloat(val);
  return isNaN(n) ? null : n;
}

interface UpsertedMarket {
  id: string;
  external_id: string;
  best_ask_yes: number | null;
  best_ask_no: number | null;
}

export async function collectMarkets(): Promise<UpsertedMarket[]> {
  await log('info', 'collector', 'Starting Kalshi market scan');

  let rawMarkets: KalshiMarket[];
  try {
    rawMarkets = await fetchOpenMarkets(1000);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await log('error', 'collector', `Failed to fetch Kalshi markets: ${msg}`);
    return [];
  }

  await log('info', 'collector', `Fetched ${rawMarkets.length} open markets from Kalshi`);

  const rows = rawMarkets.map((m) => ({
    external_id: m.ticker,
    platform: 'kalshi' as const,
    title: m.yes_sub_title || m.ticker,
    category: m.event_ticker || '',
    status: mapStatus(m.status),
    best_ask_yes: parseDollar(m.yes_ask_dollars),
    best_ask_no: parseDollar(m.no_ask_dollars),
    best_bid_yes: parseDollar(m.yes_bid_dollars),
    best_bid_no: parseDollar(m.no_bid_dollars),
    volume: parseFloat(m.volume_fp || '0') || 0,
    last_updated: new Date().toISOString(),
  }));

  const batchSize = 500;
  const upserted: UpsertedMarket[] = [];

  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    const { data, error } = await supabase
      .from('markets')
      .upsert(batch, { onConflict: 'external_id' })
      .select('id, external_id, best_ask_yes, best_ask_no');

    if (error) {
      await log('error', 'collector', `Upsert batch failed: ${error.message}`, {
        batch_start: i,
        batch_size: batch.length,
      });
      continue;
    }

    if (data) upserted.push(...data);
  }

  await log('info', 'collector', `Upserted ${upserted.length} Kalshi markets`);
  return upserted;
}
