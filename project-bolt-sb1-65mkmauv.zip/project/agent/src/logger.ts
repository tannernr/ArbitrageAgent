import { supabase } from './supabase.js';

type LogLevel = 'info' | 'warn' | 'error' | 'critical';
type Component = 'collector' | 'detector' | 'executor' | 'auditor' | 'governor';

const LEVEL_PREFIX: Record<LogLevel, string> = {
  info: 'INFO',
  warn: 'WARN',
  error: 'ERROR',
  critical: 'CRIT',
};

export async function log(
  level: LogLevel,
  component: Component,
  message: string,
  metadata?: Record<string, unknown>,
  tradeId?: string
): Promise<void> {
  const ts = new Date().toISOString();
  const prefix = LEVEL_PREFIX[level];
  console.log(`[${ts}] ${prefix} [${component}] ${message}`);

  try {
    await supabase.from('execution_logs').insert({
      log_level: level,
      component,
      message,
      metadata: metadata ?? null,
      trade_id: tradeId ?? null,
    });
  } catch {
    console.error(`Failed to write log to database`);
  }
}
