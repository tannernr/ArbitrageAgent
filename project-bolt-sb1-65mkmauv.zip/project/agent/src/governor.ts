import { supabase } from './supabase.js';
import { log } from './logger.js';

interface GovernorCheck {
  canRun: boolean;
  mode: string;
  haltReason?: string;
}

export async function checkGovernor(): Promise<GovernorCheck> {
  const { data, error } = await supabase
    .from('governor_state')
    .select('*')
    .limit(1)
    .maybeSingle();

  if (error || !data) {
    await log('error', 'governor', 'Failed to read governor state');
    return { canRun: false, mode: 'halted', haltReason: 'Cannot read governor state' };
  }

  if (!data.is_active) {
    return { canRun: false, mode: data.mode, haltReason: data.halt_reason || 'Agent halted' };
  }

  return { canRun: true, mode: data.mode };
}

export async function haltAgent(reason: string, triggerName: string, triggerValue?: string, thresholdValue?: string): Promise<void> {
  await supabase
    .from('governor_state')
    .update({
      is_active: false,
      mode: 'halted',
      halt_reason: reason,
      halted_at: new Date().toISOString(),
    })
    .neq('id', '00000000-0000-0000-0000-000000000000');

  await supabase.from('governor_events').insert({
    event_type: 'halt',
    trigger_name: triggerName,
    trigger_value: triggerValue ?? null,
    threshold_value: thresholdValue ?? null,
    message: reason,
  });

  await log('critical', 'governor', `AGENT HALTED: ${reason}`, {
    trigger_name: triggerName,
    trigger_value: triggerValue,
    threshold_value: thresholdValue,
  });
}

export async function runKillConditionChecks(): Promise<void> {
  const { data: configRows } = await supabase.from('agent_config').select('key, value');
  if (!configRows) return;

  const cfg = new Map(configRows.map((r) => [r.key, parseFloat(String(r.value).replace(/"/g, ''))]));

  const { data: perf } = await supabase
    .from('performance_snapshots')
    .select('*')
    .order('snapshot_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!perf) return;

  const maxLossPct = cfg.get('kill_max_loss_pct') ?? 0.005;
  if (perf.total_invested > 0) {
    const lossPct = Math.abs(Math.min(perf.total_profit, 0)) / perf.total_invested;
    if (lossPct >= maxLossPct) {
      await haltAgent(
        `Realized loss ${(lossPct * 100).toFixed(2)}% exceeds limit ${(maxLossPct * 100).toFixed(2)}%`,
        'kill_max_loss_pct',
        lossPct.toFixed(4),
        maxLossPct.toString()
      );
      return;
    }
  }

  const maxDrawdownPct = cfg.get('kill_max_drawdown_pct') ?? 0.01;
  if (perf.max_drawdown >= maxDrawdownPct) {
    await haltAgent(
      `Max drawdown ${(perf.max_drawdown * 100).toFixed(2)}% exceeds limit ${(maxDrawdownPct * 100).toFixed(2)}%`,
      'kill_max_drawdown_pct',
      perf.max_drawdown.toFixed(4),
      maxDrawdownPct.toString()
    );
    return;
  }

  const maxFailRate = cfg.get('kill_exec_failure_rate') ?? 0.02;
  if (perf.execution_failure_rate >= maxFailRate) {
    await haltAgent(
      `Execution failure rate ${(perf.execution_failure_rate * 100).toFixed(2)}% exceeds limit ${(maxFailRate * 100).toFixed(2)}%`,
      'kill_exec_failure_rate',
      perf.execution_failure_rate.toFixed(4),
      maxFailRate.toString()
    );
    return;
  }

  const { data: gov } = await supabase.from('governor_state').select('consecutive_days_no_arb').limit(1).maybeSingle();
  const maxNoArbDays = cfg.get('kill_no_arb_days') ?? 7;
  if (gov && gov.consecutive_days_no_arb >= maxNoArbDays) {
    await haltAgent(
      `No arbitrage detected for ${gov.consecutive_days_no_arb} consecutive days (limit: ${maxNoArbDays})`,
      'kill_no_arb_days',
      String(gov.consecutive_days_no_arb),
      String(maxNoArbDays)
    );
  }
}
