import { supabase } from './supabase.js';
import { collectMarkets } from './collector.js';
import { detectArbitrage } from './detector.js';
import { checkGovernor, runKillConditionChecks } from './governor.js';
import { log } from './logger.js';

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getScanInterval(): Promise<number> {
  const { data } = await supabase
    .from('agent_config')
    .select('value')
    .eq('key', 'scan_interval_seconds')
    .maybeSingle();

  const val = data ? parseInt(String(data.value).replace(/"/g, ''), 10) : 30;
  return (isNaN(val) ? 30 : val) * 1000;
}

async function runCycle(): Promise<void> {
  const governor = await checkGovernor();

  if (!governor.canRun) {
    await log('warn', 'governor', `Agent is ${governor.mode}: ${governor.haltReason}`);
    return;
  }

  await log('info', 'collector', `Cycle starting in ${governor.mode} mode`);

  const markets = await collectMarkets();

  if (markets.length === 0) {
    await log('warn', 'collector', 'No markets collected this cycle');
    return;
  }

  const opportunityCount = await detectArbitrage(markets);

  if (opportunityCount > 0) {
    await log('info', 'detector', `Found ${opportunityCount} arbitrage opportunities`);
  }

  await runKillConditionChecks();
}

async function main(): Promise<void> {
  console.log('=== Survival Arbitrage Agent ===');
  console.log(`Kalshi base: ${process.env.KALSHI_BASE_URL || 'https://api.elections.kalshi.com/trade-api/v2'}`);

  await log('info', 'collector', 'Agent process started');

  const { data: gov } = await supabase.from('governor_state').select('is_active, mode').limit(1).maybeSingle();
  if (gov) {
    console.log(`Governor: active=${gov.is_active}, mode=${gov.mode}`);
  }

  while (true) {
    try {
      await runCycle();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      await log('error', 'collector', `Cycle crashed: ${msg}`, {
        stack: err instanceof Error ? err.stack : undefined,
      });
    }

    const interval = await getScanInterval();
    await sleep(interval);
  }
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
