import { supabase } from './supabase.js';
import { log } from './logger.js';

interface MarketRow {
  id: string;
  external_id: string;
  best_ask_yes: number | null;
  best_ask_no: number | null;
}

interface AgentParams {
  feeRate: number;
  safetyMargin: number;
}

async function loadAgentParams(): Promise<AgentParams> {
  const { data } = await supabase
    .from('agent_config')
    .select('key, value')
    .in('key', ['fee_rate', 'safety_margin']);

  const params: AgentParams = { feeRate: 0.02, safetyMargin: 0.02 };
  if (data) {
    for (const row of data) {
      const val = parseFloat(String(row.value).replace(/"/g, ''));
      if (row.key === 'fee_rate' && !isNaN(val)) params.feeRate = val;
      if (row.key === 'safety_margin' && !isNaN(val)) params.safetyMargin = val;
    }
  }
  return params;
}

export async function detectArbitrage(markets: MarketRow[]): Promise<number> {
  const params = await loadAgentParams();
  let detected = 0;

  for (const market of markets) {
    if (market.best_ask_yes == null || market.best_ask_no == null) continue;
    if (market.best_ask_yes <= 0 || market.best_ask_no <= 0) continue;

    const totalCost = market.best_ask_yes + market.best_ask_no;
    const fees = totalCost * params.feeRate;
    const costWithFees = totalCost + fees + params.safetyMargin;
    const estimatedProfit = 1.0 - costWithFees;

    if (estimatedProfit <= 0) continue;

    const profitMargin = estimatedProfit / costWithFees;

    const { error } = await supabase.from('arbitrage_opportunities').insert({
      market_id: market.id,
      best_ask_yes: market.best_ask_yes,
      best_ask_no: market.best_ask_no,
      total_cost: totalCost,
      estimated_profit: estimatedProfit,
      profit_margin: profitMargin,
      fees,
      safety_margin: params.safetyMargin,
      status: 'detected',
    });

    if (error) {
      await log('warn', 'detector', `Failed to insert opportunity: ${error.message}`, {
        market_id: market.id,
        external_id: market.external_id,
      });
      continue;
    }

    detected++;
    await log('info', 'detector', `Arbitrage detected on ${market.external_id}`, {
      market_id: market.id,
      yes_ask: market.best_ask_yes,
      no_ask: market.best_ask_no,
      total_cost: totalCost,
      estimated_profit: estimatedProfit,
      profit_margin: (profitMargin * 100).toFixed(2) + '%',
    });
  }

  if (detected > 0) {
    await supabase
      .from('governor_state')
      .update({ last_opportunity_at: new Date().toISOString(), consecutive_days_no_arb: 0 })
      .neq('id', '00000000-0000-0000-0000-000000000000');
  }

  await log('info', 'detector', `Detection complete: ${detected} opportunities from ${markets.length} markets`);
  return detected;
}
