/*
  # Update market platforms to include Kalshi

  1. Changes
    - Updates `market_platforms` config to include both polymarket and kalshi
  2. Notes
    - Uses ON CONFLICT to safely handle existing key
*/

UPDATE agent_config
SET value = '["polymarket", "kalshi"]', updated_at = now()
WHERE key = 'market_platforms';
