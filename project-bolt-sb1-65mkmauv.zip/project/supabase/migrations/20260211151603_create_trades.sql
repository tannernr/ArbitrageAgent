/*
  # Trades Table
  - Executed or simulated trades linked to markets and opportunities
  - RLS enabled, read-only for dashboard
*/
CREATE TABLE IF NOT EXISTS trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_id uuid REFERENCES arbitrage_opportunities(id),
  market_id uuid NOT NULL REFERENCES markets(id),
  side_yes_price numeric NOT NULL,
  side_no_price numeric NOT NULL,
  size numeric NOT NULL,
  total_cost numeric NOT NULL,
  expected_profit numeric NOT NULL,
  actual_profit numeric,
  status text NOT NULL DEFAULT 'pending',
  execution_mode text NOT NULL DEFAULT 'dry_run',
  executed_at timestamptz DEFAULT now(),
  settled_at timestamptz
);

ALTER TABLE trades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read trades"
  ON trades FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_executed ON trades(executed_at);
CREATE INDEX IF NOT EXISTS idx_trades_market ON trades(market_id);