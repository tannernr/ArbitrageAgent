/*
  # Execution Logs Table
  - Structured logs from all agent components
  - FK to trades (nullable)
  - RLS enabled, read-only for dashboard
*/
CREATE TABLE IF NOT EXISTS execution_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_id uuid REFERENCES trades(id),
  log_level text NOT NULL DEFAULT 'info',
  component text NOT NULL,
  message text NOT NULL,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE execution_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read logs"
  ON execution_logs FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_logs_level ON execution_logs(log_level);
CREATE INDEX IF NOT EXISTS idx_logs_component ON execution_logs(component);
CREATE INDEX IF NOT EXISTS idx_logs_created ON execution_logs(created_at);