/*
  # Markets Table
  - Tracked prediction markets from Polymarket/Kalshi
  - RLS enabled, read-only for dashboard
*/
CREATE TABLE IF NOT EXISTS markets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id text UNIQUE NOT NULL,
  platform text NOT NULL,
  title text NOT NULL,
  category text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  best_ask_yes numeric,
  best_ask_no numeric,
  best_bid_yes numeric,
  best_bid_no numeric,
  volume numeric DEFAULT 0,
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE markets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read markets"
  ON markets FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_markets_status ON markets(status);
CREATE INDEX IF NOT EXISTS idx_markets_platform ON markets(platform);