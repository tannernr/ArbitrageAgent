/*
  # Seed Default Configuration
  - Default agent parameters for arbitrage detection
  - Initial governor state (active, dry_run mode)
*/
INSERT INTO agent_config (key, value, description) VALUES
  ('initial_capital', '10000', 'Starting capital in USD'),
  ('max_trade_size', '100', 'Maximum size per trade in USD'),
  ('safety_margin', '0.02', 'Safety margin added to arbitrage cost calculation'),
  ('fee_rate', '0.02', 'Platform fee rate (2%)'),
  ('kill_max_loss_pct', '0.005', 'Kill condition: max realized loss percentage (0.5%)'),
  ('kill_max_drawdown_pct', '0.01', 'Kill condition: max drawdown percentage (1%)'),
  ('kill_exec_failure_rate', '0.02', 'Kill condition: max execution failure rate (2%)'),
  ('kill_no_arb_days', '7', 'Kill condition: consecutive days with no valid arbitrage'),
  ('execution_mode', '"dry_run"', 'Current execution mode: dry_run, paper, or live'),
  ('scan_interval_seconds', '30', 'Seconds between market scans'),
  ('market_platforms', '["polymarket"]', 'Enabled market platforms'),
  ('alert_webhook_url', '""', 'Webhook URL for alerts (empty = disabled)')
ON CONFLICT (key) DO NOTHING;

INSERT INTO governor_state (is_active, mode) VALUES (true, 'dry_run');