/*
  # Arbitrage Opportunities Table
  - Detected arb opportunities linked to markets
  - RLS enabled, read-only for dashboard
*/
CREATE TABLE IF NOT EXISTS arbitrage_opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id uuid NOT NULL REFERENCES markets(id),
  best_ask_yes numeric NOT NULL,
  best_ask_no numeric NOT NULL,
  total_cost numeric NOT NULL,
  estimated_profit numeric NOT NULL,
  profit_margin numeric NOT NULL,
  fees numeric NOT NULL DEFAULT 0,
  safety_margin numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'detected',
  detected_at timestamptz DEFAULT now()
);

ALTER TABLE arbitrage_opportunities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read opportunities"
  ON arbitrage_opportunities FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_opportunities_status ON arbitrage_opportunities(status);
CREATE INDEX IF NOT EXISTS idx_opportunities_detected ON arbitrage_opportunities(detected_at);