/*
  # Arbitrage Opportunities and Trades Tables

  1. New Tables
    - `arbitrage_opportunities` - Detected arb opportunities
      - `id` (uuid, primary key)
      - `market_id` (uuid, FK to markets)
      - price, cost, profit, margin, fee fields
      - `status` - detected, executed, expired, skipped
      - `detected_at` (timestamptz)
    - `trades` - Executed or simulated trades
      - `id` (uuid, primary key)
      - `opportunity_id` (uuid, FK)
      - `market_id` (uuid, FK)
      - price, size, cost, profit fields
      - `status` - pending, executed, settled, failed, aborted
      - `execution_mode` - dry_run, paper, live
      - timestamps

  2. Security
    - RLS enabled on both tables
    - Read-only SELECT for dashboard
*/

CREATE TABLE IF NOT EXISTS arbitrage_opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id uuid NOT NULL REFERENCES markets(id),
  best_ask_yes numeric NOT NULL,
  best_ask_no numeric NOT NULL,
  total_cost numeric NOT NULL,
  estimated_profit numeric NOT NULL,
  profit_margin numeric NOT NULL,
  fees numeric NOT NULL DEFAULT 0,
  safety_margin numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'detected',
  detected_at timestamptz DEFAULT now()
);

ALTER TABLE arbitrage_opportunities ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read opportunities"
  ON arbitrage_opportunities FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_opportunities_status ON arbitrage_opportunities(status);
CREATE INDEX IF NOT EXISTS idx_opportunities_detected ON arbitrage_opportunities(detected_at);

CREATE TABLE IF NOT EXISTS trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_id uuid REFERENCES arbitrage_opportunities(id),
  market_id uuid NOT NULL REFERENCES markets(id),
  side_yes_price numeric NOT NULL,
  side_no_price numeric NOT NULL,
  size numeric NOT NULL,
  total_cost numeric NOT NULL,
  expected_profit numeric NOT NULL,
  actual_profit numeric,
  status text NOT NULL DEFAULT 'pending',
  execution_mode text NOT NULL DEFAULT 'dry_run',
  executed_at timestamptz DEFAULT now(),
  settled_at timestamptz
);

ALTER TABLE trades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read trades"
  ON trades FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_executed ON trades(executed_at);
CREATE INDEX IF NOT EXISTS idx_trades_market ON trades(market_id);