/*
  # Performance Snapshots and Governor Tables

  1. New Tables
    - `performance_snapshots` - Periodic performance metrics
      - trade counts, profit, ROI, win rate, drawdown, failure rate
      - `snapshot_at` (timestamptz)
    - `governor_state` - Survival governor current state
      - `is_active` (boolean)
      - `mode` - dry_run, paper, live, halted
      - tracking fields for last trade, opportunities, halt reasons
    - `governor_events` - Governor decision log
      - event_type, trigger details, threshold values, message

  2. Security
    - RLS enabled on all tables
    - Read-only SELECT for dashboard
*/

CREATE TABLE IF NOT EXISTS performance_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  total_trades integer NOT NULL DEFAULT 0,
  winning_trades integer NOT NULL DEFAULT 0,
  losing_trades integer NOT NULL DEFAULT 0,
  total_profit numeric NOT NULL DEFAULT 0,
  total_invested numeric NOT NULL DEFAULT 0,
  roi numeric NOT NULL DEFAULT 0,
  win_rate numeric NOT NULL DEFAULT 0,
  max_drawdown numeric NOT NULL DEFAULT 0,
  current_drawdown numeric NOT NULL DEFAULT 0,
  execution_failure_count integer NOT NULL DEFAULT 0,
  execution_failure_rate numeric NOT NULL DEFAULT 0,
  snapshot_at timestamptz DEFAULT now()
);

ALTER TABLE performance_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read performance"
  ON performance_snapshots FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_performance_snapshot ON performance_snapshots(snapshot_at);

CREATE TABLE IF NOT EXISTS governor_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  is_active boolean NOT NULL DEFAULT true,
  mode text NOT NULL DEFAULT 'dry_run',
  last_trade_at timestamptz,
  last_opportunity_at timestamptz,
  consecutive_days_no_arb integer NOT NULL DEFAULT 0,
  halt_reason text,
  halted_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE governor_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read governor state"
  ON governor_state FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE TABLE IF NOT EXISTS governor_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  trigger_name text NOT NULL,
  trigger_value text,
  threshold_value text,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE governor_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read governor events"
  ON governor_events FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_governor_events_type ON governor_events(event_type);
CREATE INDEX IF NOT EXISTS idx_governor_events_created ON governor_events(created_at);