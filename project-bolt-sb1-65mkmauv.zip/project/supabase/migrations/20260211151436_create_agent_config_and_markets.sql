/*
  # Agent Config and Markets Tables

  1. New Tables
    - `agent_config` - Key-value config store for all agent parameters
      - `id` (uuid, primary key)
      - `key` (text, unique) - config parameter name
      - `value` (jsonb) - config value
      - `description` (text) - human-readable description
      - `updated_at` (timestamptz)
    - `markets` - Tracked prediction markets
      - `id` (uuid, primary key)
      - `external_id` (text, unique) - platform market ID
      - `platform` (text) - polymarket or kalshi
      - `title` (text) - market question
      - `category` (text) - market category
      - `status` (text) - active, settled, expired
      - price and volume fields
      - timestamps

  2. Security
    - RLS enabled on both tables
    - Read-only SELECT for dashboard via anon role
    - Writes restricted to service_role (Python agent)
*/

CREATE TABLE IF NOT EXISTS agent_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  description text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE agent_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read config"
  ON agent_config FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE TABLE IF NOT EXISTS markets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id text UNIQUE NOT NULL,
  platform text NOT NULL,
  title text NOT NULL,
  category text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  best_ask_yes numeric,
  best_ask_no numeric,
  best_bid_yes numeric,
  best_bid_no numeric,
  volume numeric DEFAULT 0,
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE markets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read markets"
  ON markets FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

CREATE INDEX IF NOT EXISTS idx_markets_status ON markets(status);
CREATE INDEX IF NOT EXISTS idx_markets_platform ON markets(platform);