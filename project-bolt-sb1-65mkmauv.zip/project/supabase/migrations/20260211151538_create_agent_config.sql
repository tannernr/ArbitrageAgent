/*
  # Agent Config Table
  - `agent_config` - Key-value configuration store
  - RLS enabled, read-only for dashboard
*/
CREATE TABLE IF NOT EXISTS agent_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  description text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE agent_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Dashboard can read config"
  ON agent_config FOR SELECT
  TO anon
  USING (auth.role() = 'anon');