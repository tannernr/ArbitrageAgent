/*
  # Survival Arbitrage Agent - Full Schema

  1. Tables: agent_config, markets, arbitrage_opportunities, trades,
     performance_snapshots, governor_state, governor_events, execution_logs
  2. RLS enabled on all tables with read-only dashboard access
  3. Default configuration seeded
  4. Initial governor state seeded
*/

CREATE TABLE IF NOT EXISTS agent_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  description text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE agent_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read config" ON agent_config FOR SELECT TO anon USING (auth.role() = 'anon');

CREATE TABLE IF NOT EXISTS markets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id text UNIQUE NOT NULL,
  platform text NOT NULL,
  title text NOT NULL,
  category text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  best_ask_yes numeric,
  best_ask_no numeric,
  best_bid_yes numeric,
  best_bid_no numeric,
  volume numeric DEFAULT 0,
  last_updated timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE markets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read markets" ON markets FOR SELECT TO anon USING (auth.role() = 'anon');
CREATE INDEX IF NOT EXISTS idx_markets_status ON markets(status);
CREATE INDEX IF NOT EXISTS idx_markets_platform ON markets(platform);

CREATE TABLE IF NOT EXISTS arbitrage_opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id uuid NOT NULL REFERENCES markets(id),
  best_ask_yes numeric NOT NULL,
  best_ask_no numeric NOT NULL,
  total_cost numeric NOT NULL,
  estimated_profit numeric NOT NULL,
  profit_margin numeric NOT NULL,
  fees numeric NOT NULL DEFAULT 0,
  safety_margin numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'detected',
  detected_at timestamptz DEFAULT now()
);

ALTER TABLE arbitrage_opportunities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read opportunities" ON arbitrage_opportunities FOR SELECT TO anon USING (auth.role() = 'anon');
CREATE INDEX IF NOT EXISTS idx_opportunities_status ON arbitrage_opportunities(status);
CREATE INDEX IF NOT EXISTS idx_opportunities_detected ON arbitrage_opportunities(detected_at);

CREATE TABLE IF NOT EXISTS trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_id uuid REFERENCES arbitrage_opportunities(id),
  market_id uuid NOT NULL REFERENCES markets(id),
  side_yes_price numeric NOT NULL,
  side_no_price numeric NOT NULL,
  size numeric NOT NULL,
  total_cost numeric NOT NULL,
  expected_profit numeric NOT NULL,
  actual_profit numeric,
  status text NOT NULL DEFAULT 'pending',
  execution_mode text NOT NULL DEFAULT 'dry_run',
  executed_at timestamptz DEFAULT now(),
  settled_at timestamptz
);

ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read trades" ON trades FOR SELECT TO anon USING (auth.role() = 'anon');
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_executed ON trades(executed_at);
CREATE INDEX IF NOT EXISTS idx_trades_market ON trades(market_id);

CREATE TABLE IF NOT EXISTS performance_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  total_trades integer NOT NULL DEFAULT 0,
  winning_trades integer NOT NULL DEFAULT 0,
  losing_trades integer NOT NULL DEFAULT 0,
  total_profit numeric NOT NULL DEFAULT 0,
  total_invested numeric NOT NULL DEFAULT 0,
  roi numeric NOT NULL DEFAULT 0,
  win_rate numeric NOT NULL DEFAULT 0,
  max_drawdown numeric NOT NULL DEFAULT 0,
  current_drawdown numeric NOT NULL DEFAULT 0,
  execution_failure_count integer NOT NULL DEFAULT 0,
  execution_failure_rate numeric NOT NULL DEFAULT 0,
  snapshot_at timestamptz DEFAULT now()
);

ALTER TABLE performance_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read performance" ON performance_snapshots FOR SELECT TO anon USING (auth.role() = 'anon');
CREATE INDEX IF NOT EXISTS idx_performance_snapshot ON performance_snapshots(snapshot_at);

CREATE TABLE IF NOT EXISTS governor_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  is_active boolean NOT NULL DEFAULT true,
  mode text NOT NULL DEFAULT 'dry_run',
  last_trade_at timestamptz,
  last_opportunity_at timestamptz,
  consecutive_days_no_arb integer NOT NULL DEFAULT 0,
  halt_reason text,
  halted_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE governor_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read governor state" ON governor_state FOR SELECT TO anon USING (auth.role() = 'anon');

CREATE TABLE IF NOT EXISTS governor_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  trigger_name text NOT NULL,
  trigger_value text,
  threshold_value text,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE governor_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read governor events" ON governor_events FOR SELECT TO anon USING (auth.role() = 'anon');
CREATE INDEX IF NOT EXISTS idx_governor_events_type ON governor_events(event_type);
CREATE INDEX IF NOT EXISTS idx_governor_events_created ON governor_events(created_at);

CREATE TABLE IF NOT EXISTS execution_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_id uuid REFERENCES trades(id),
  log_level text NOT NULL DEFAULT 'info',
  component text NOT NULL,
  message text NOT NULL,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE execution_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dashboard can read logs" ON execution_logs FOR SELECT TO anon USING (auth.role() = 'anon');
CREATE INDEX IF NOT EXISTS idx_logs_level ON execution_logs(log_level);
CREATE INDEX IF NOT EXISTS idx_logs_component ON execution_logs(component);
CREATE INDEX IF NOT EXISTS idx_logs_created ON execution_logs(created_at);

INSERT INTO agent_config (key, value, description) VALUES
  ('initial_capital', '10000', 'Starting capital in USD'),
  ('max_trade_size', '100', 'Maximum size per trade in USD'),
  ('safety_margin', '0.02', 'Safety margin added to arbitrage cost calculation'),
  ('fee_rate', '0.02', 'Platform fee rate (2%)'),
  ('kill_max_loss_pct', '0.005', 'Kill condition: max realized loss percentage (0.5%)'),
  ('kill_max_drawdown_pct', '0.01', 'Kill condition: max drawdown percentage (1%)'),
  ('kill_exec_failure_rate', '0.02', 'Kill condition: max execution failure rate (2%)'),
  ('kill_no_arb_days', '7', 'Kill condition: consecutive days with no valid arbitrage'),
  ('execution_mode', '"dry_run"', 'Current execution mode: dry_run, paper, or live'),
  ('scan_interval_seconds', '30', 'Seconds between market scans'),
  ('market_platforms', '["polymarket"]', 'Enabled market platforms'),
  ('alert_webhook_url', '""', 'Webhook URL for alerts (empty = disabled)')
ON CONFLICT (key) DO NOTHING;

INSERT INTO governor_state (is_active, mode) VALUES (true, 'dry_run');
